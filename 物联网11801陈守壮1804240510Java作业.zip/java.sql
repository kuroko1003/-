/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50729
 Source Host           : localhost:3306
 Source Schema         : java

 Target Server Type    : MySQL
 Target Server Version : 50729
 File Encoding         : 65001

 Date: 20/06/2020 16:57:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for base
-- ----------------------------
DROP TABLE IF EXISTS `base`;
CREATE TABLE `base`  (
  `id` int(255) NOT NULL,
  `text` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `A` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `B` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `C` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `D` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `answer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of base
-- ----------------------------
INSERT INTO `base` VALUES (1, '俄罗斯首都是哪座城市', 'A.莫斯科', 'B.伦敦', 'C.纽约', 'D.米兰', 'A');
INSERT INTO `base` VALUES (2, '北京运动会是哪一年召开的', 'A.2006', 'B.2008', 'C.2010', 'D.2012', 'B');
INSERT INTO `base` VALUES (3, '周杰伦的夜曲是他哪个专辑内的歌曲', 'A.七里香', 'B.十一月的肖邦', 'C.范特西', 'D.叶惠美', 'B');
INSERT INTO `base` VALUES (4, '周杰伦歌曲Mojito中Mojito指的是什么', 'A.啤酒', 'B.红酒', 'C.鸡尾酒', 'D.白酒', 'C');
INSERT INTO `base` VALUES (5, '”月下整夜，我的爱溢出就像雨水“出自哪首歌曲', 'A.夜曲', 'B.彩虹', 'C.晴天', 'D.七里香', 'D');
INSERT INTO `base` VALUES (6, '《女生徒》是谁的作品', 'A.川端康成', 'B.夏目漱石', 'C.村上春树', 'D.太宰治', 'D');
INSERT INTO `base` VALUES (7, '《人间失格》中主角是一个怎样的形象', 'A.乐观开朗', 'B.心狠手辣', 'C.极度消极', 'D.随遇而安', 'C');
INSERT INTO `base` VALUES (8, '《伊豆的舞女》中女主角舞女多少岁', 'A.16', 'B.17', 'C.14', 'D.15', 'C');
INSERT INTO `base` VALUES (9, '下列选项中是日语中无聊的选项是', 'A.正しい', 'B.つまらない', 'C.おいしい', 'D.はやい', 'B');
INSERT INTO `base` VALUES (10, '下列选项中是日语中朋友的意思的选项是', 'A.仲間', 'B.友達', 'C.素人', 'D.玄人', 'B');

SET FOREIGN_KEY_CHECKS = 1;
